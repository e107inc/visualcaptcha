[![Codacy](https://www.codacy.com/project/badge/f4d52c3f12a14d9bac7205863796456a)](https://www.codacy.com/app/bruno-bernardino/visualCaptcha-WordPress)
[![Code Climate](https://codeclimate.com/github/emotionLoop/visualCaptcha-WordPress/badges/gpa.svg)](https://codeclimate.com/github/emotionLoop/visualCaptcha-WordPress)

# visualCaptcha for WordPress

The visualCaptcha WordPress plugin is at http://wordpress.org/plugins/visualcaptcha/

This repo is copied to the WordPress subversion one, we just prefer git to actually manage the code.

Composer and its packages are versioned because that makes it easier to just copy + deploy to the WordPress official SVN repo.

## Current Version

Current version is 5.0.6.

## Demo

You can view visualCaptcha's demo at http://demo.visualcaptcha.net. Note the demo is the PHP version ( https://github.com/emotionLoop/visualCaptcha-PHP ), not the WordPress version, but they should work similarly.

## More information

If you want information about what visualCaptcha is, go to http://visualcaptcha.net.
